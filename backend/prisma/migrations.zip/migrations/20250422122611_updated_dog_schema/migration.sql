-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Dog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "showTitle" TEXT,
    "dogName" TEXT NOT NULL,
    "friendlyUrl" TEXT,
    "kennel" TEXT,
    "breeder" TEXT,
    "breedId" INTEGER,
    "sireId" INTEGER,
    "damId" INTEGER,
    "dob" DATETIME,
    "isDeath" BOOLEAN NOT NULL DEFAULT false,
    "isSold" BOOLEAN NOT NULL DEFAULT false,
    "isLoan" BOOLEAN NOT NULL DEFAULT false,
    "isTransfer" BOOLEAN NOT NULL DEFAULT false,
    "sex" TEXT NOT NULL,
    "achievements" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "countryId" INTEGER,
    "cityId" INTEGER,
    "categoryId" INTEGER,
    "KP" TEXT,
    "location" TEXT,
    "microchip" TEXT,
    "HD" TEXT,
    "ED" TEXT,
    "hair" TEXT,
    "color" TEXT,
    CONSTRAINT "Dog_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES "Country" ("idCountry") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_cityId_fkey" FOREIGN KEY ("cityId") REFERENCES "City" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "DogCategory" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Dog" ("ED", "HD", "KP", "achievements", "breedId", "breeder", "categoryId", "cityId", "color", "countryId", "createdAt", "damId", "dob", "dogName", "friendlyUrl", "hair", "id", "isDeath", "isLoan", "isSold", "isTransfer", "kennel", "location", "microchip", "sex", "showTitle", "sireId", "status", "updatedAt") SELECT "ED", "HD", "KP", "achievements", "breedId", "breeder", "categoryId", "cityId", "color", "countryId", "createdAt", "damId", "dob", "dogName", "friendlyUrl", "hair", "id", "isDeath", "isLoan", "isSold", "isTransfer", "kennel", "location", "microchip", "sex", "showTitle", "sireId", "status", "updatedAt" FROM "Dog";
DROP TABLE "Dog";
ALTER TABLE "new_Dog" RENAME TO "Dog";
CREATE UNIQUE INDEX "Dog_KP_key" ON "Dog"("KP");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
