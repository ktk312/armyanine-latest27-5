-- AlterTable
ALTER TABLE "Litter" ADD COLUMN "Remarks" TEXT;
ALTER TABLE "Litter" ADD COLUMN "conditionOfDam" TEXT;
ALTER TABLE "Litter" ADD COLUMN "conditionOfPuppies" TEXT;
ALTER TABLE "Litter" ADD COLUMN "uniformFeature" TEXT;
