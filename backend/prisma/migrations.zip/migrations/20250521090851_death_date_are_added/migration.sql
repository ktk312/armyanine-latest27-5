-- AlterTable
ALTER TABLE "Dog" ADD COLUMN "loanDate" TEXT;
ALTER TABLE "Dog" ADD COLUMN "soldDate" TEXT;
ALTER TABLE "Dog" ADD COLUMN "transferDate" TEXT;
