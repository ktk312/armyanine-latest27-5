-- AlterTable
ALTER TABLE "Dog" ADD COLUMN "CDN" BOOLEAN DEFAULT false;
ALTER TABLE "Dog" ADD COLUMN "CNS" BOOLEAN DEFAULT false;
ALTER TABLE "Dog" ADD COLUMN "breedingAdvice" TEXT;
ALTER TABLE "Dog" ADD COLUMN "miscellaneousComments" TEXT;
ALTER TABLE "Dog" ADD COLUMN "progenyTrainability" TEXT;
ALTER TABLE "Dog" ADD COLUMN "virtuesAndFaults" TEXT;

-- AlterTable
ALTER TABLE "LitterDetail" ADD COLUMN "status" TEXT;

-- CreateTable
CREATE TABLE "Microchip" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "chipId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE UNIQUE INDEX "Microchip_chipId_key" ON "Microchip"("chipId");
