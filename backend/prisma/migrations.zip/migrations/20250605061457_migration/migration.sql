-- AlterTable
ALTER TABLE "Dog" ADD COLUMN "chestCircumference" TEXT;
ALTER TABLE "Dog" ADD COLUMN "chestDepth" TEXT;
ALTER TABLE "Dog" ADD COLUMN "weight" TEXT;
