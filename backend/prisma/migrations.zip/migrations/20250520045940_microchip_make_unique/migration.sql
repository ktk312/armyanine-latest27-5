/*
  Warnings:

  - A unique constraint covering the columns `[microchipId]` on the table `Dog` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "Dog_microchipId_key" ON "Dog"("microchipId");
