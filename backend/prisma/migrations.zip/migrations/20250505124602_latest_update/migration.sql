/*
  Warnings:

  - You are about to drop the column `microchip` on the `Dog` table. All the data in the column will be lost.
  - You are about to drop the column `microchip` on the `LitterDetail` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Dog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "showTitle" TEXT,
    "dogName" TEXT NOT NULL,
    "friendlyUrl" TEXT,
    "kennel" TEXT,
    "breeder" TEXT,
    "breedId" INTEGER,
    "sireId" INTEGER,
    "damId" INTEGER,
    "dob" DATETIME,
    "isDeath" BOOLEAN NOT NULL DEFAULT false,
    "isSold" BOOLEAN NOT NULL DEFAULT false,
    "isLoan" BOOLEAN NOT NULL DEFAULT false,
    "isTransfer" BOOLEAN NOT NULL DEFAULT false,
    "CDN" BOOLEAN DEFAULT false,
    "CNS" BOOLEAN DEFAULT false,
    "sex" TEXT NOT NULL,
    "achievements" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "countryId" INTEGER,
    "cityId" INTEGER,
    "categoryId" INTEGER,
    "KP" TEXT,
    "location" TEXT,
    "microchipId" INTEGER,
    "HD" TEXT,
    "ED" TEXT,
    "hair" TEXT,
    "color" TEXT,
    "virtuesAndFaults" TEXT,
    "breedingAdvice" TEXT,
    "miscellaneousComments" TEXT,
    "progenyTrainability" TEXT,
    CONSTRAINT "Dog_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES "Country" ("idCountry") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_cityId_fkey" FOREIGN KEY ("cityId") REFERENCES "City" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "DogCategory" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_microchipId_fkey" FOREIGN KEY ("microchipId") REFERENCES "Microchip" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Dog" ("CDN", "CNS", "ED", "HD", "KP", "achievements", "breedId", "breeder", "breedingAdvice", "categoryId", "cityId", "color", "countryId", "createdAt", "damId", "dob", "dogName", "friendlyUrl", "hair", "id", "isDeath", "isLoan", "isSold", "isTransfer", "kennel", "location", "miscellaneousComments", "progenyTrainability", "sex", "showTitle", "sireId", "status", "updatedAt", "virtuesAndFaults") SELECT "CDN", "CNS", "ED", "HD", "KP", "achievements", "breedId", "breeder", "breedingAdvice", "categoryId", "cityId", "color", "countryId", "createdAt", "damId", "dob", "dogName", "friendlyUrl", "hair", "id", "isDeath", "isLoan", "isSold", "isTransfer", "kennel", "location", "miscellaneousComments", "progenyTrainability", "sex", "showTitle", "sireId", "status", "updatedAt", "virtuesAndFaults" FROM "Dog";
DROP TABLE "Dog";
ALTER TABLE "new_Dog" RENAME TO "Dog";
CREATE UNIQUE INDEX "Dog_KP_key" ON "Dog"("KP");
CREATE TABLE "new_LitterDetail" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "litterId" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "sex" TEXT NOT NULL,
    "color" TEXT,
    "hair" TEXT,
    "dnaTaken" BOOLEAN NOT NULL DEFAULT false,
    "microchipId" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "KP" TEXT,
    "status" TEXT,
    CONSTRAINT "LitterDetail_litterId_fkey" FOREIGN KEY ("litterId") REFERENCES "Litter" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "LitterDetail_microchipId_fkey" FOREIGN KEY ("microchipId") REFERENCES "Microchip" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_LitterDetail" ("KP", "color", "createdAt", "dnaTaken", "hair", "id", "litterId", "location", "name", "sex", "status", "updatedAt") SELECT "KP", "color", "createdAt", "dnaTaken", "hair", "id", "litterId", "location", "name", "sex", "status", "updatedAt" FROM "LitterDetail";
DROP TABLE "LitterDetail";
ALTER TABLE "new_LitterDetail" RENAME TO "LitterDetail";
CREATE UNIQUE INDEX "LitterDetail_KP_key" ON "LitterDetail"("KP");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
