/*
  Warnings:

  - You are about to drop the column `breedLocation` on the `Litter` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Litter" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "ownerId" INTEGER,
    "kennelId" INTEGER,
    "breedId" INTEGER NOT NULL,
    "location" TEXT,
    "dob" DATETIME NOT NULL,
    "matingDate" DATETIME NOT NULL,
    "registeredDogs" INTEGER,
    "noOfPuppies" INTEGER NOT NULL,
    "sireId" INTEGER NOT NULL,
    "damId" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "cityId" INTEGER,
    "noOfFemale" INTEGER,
    "noOfMale" INTEGER,
    "noOfExpired" INTEGER,
    CONSTRAINT "Litter_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Litter_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Litter_cityId_fkey" FOREIGN KEY ("cityId") REFERENCES "City" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Litter_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_Litter" ("breedId", "cityId", "createdAt", "damId", "dob", "id", "kennelId", "matingDate", "noOfExpired", "noOfFemale", "noOfMale", "noOfPuppies", "ownerId", "registeredDogs", "sireId", "status", "updatedAt") SELECT "breedId", "cityId", "createdAt", "damId", "dob", "id", "kennelId", "matingDate", "noOfExpired", "noOfFemale", "noOfMale", "noOfPuppies", "ownerId", "registeredDogs", "sireId", "status", "updatedAt" FROM "Litter";
DROP TABLE "Litter";
ALTER TABLE "new_Litter" RENAME TO "Litter";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
