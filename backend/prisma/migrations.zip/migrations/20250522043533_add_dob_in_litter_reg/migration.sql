-- AlterTable
ALTER TABLE "LitterDetail" ADD COLUMN "dob" TEXT;
ALTER TABLE "LitterDetail" ADD COLUMN "matingDate" TEXT;
