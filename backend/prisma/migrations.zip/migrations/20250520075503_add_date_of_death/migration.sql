-- AlterTable
ALTER TABLE "Dog" ADD COLUMN "deathDate" TEXT;
