-- CreateTable
CREATE TABLE "User" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role" TEXT DEFAULT 'breeder',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "ActivityLog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "activityDatetime" DATETIME,
    "userId" INTEGER,
    "activityName" TEXT,
    "moduleId" INTEGER,
    "userIp" TEXT,
    "userAgent" TEXT,
    "description" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "ActivityLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Breed" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "groupId" INTEGER,
    "breed" TEXT,
    "friendlyUrl" TEXT,
    "description" TEXT,
    "image" TEXT,
    "breedStandard" TEXT,
    "redirect" TEXT,
    "status" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false
);

-- CreateTable
CREATE TABLE "City" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "countryId" INTEGER NOT NULL,
    "city" TEXT,
    "status" TEXT,
    CONSTRAINT "City_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES "Country" ("idCountry") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Country" (
    "idCountry" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "countryCode" TEXT,
    "countryName" TEXT,
    "currencyCode" TEXT,
    "continent" TEXT
);

-- CreateTable
CREATE TABLE "Dog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "showTitle" TEXT,
    "dogName" TEXT NOT NULL,
    "friendlyUrl" TEXT,
    "kennel" TEXT,
    "breeder" TEXT,
    "breedId" INTEGER NOT NULL,
    "sireId" INTEGER,
    "damId" INTEGER,
    "dob" DATETIME,
    "isDeath" BOOLEAN NOT NULL DEFAULT false,
    "isSold" BOOLEAN NOT NULL DEFAULT false,
    "isLoan" BOOLEAN NOT NULL DEFAULT false,
    "isTransfer" BOOLEAN NOT NULL DEFAULT false,
    "sex" TEXT NOT NULL,
    "achievements" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "countryId" INTEGER NOT NULL,
    "cityId" INTEGER,
    "categoryId" INTEGER NOT NULL,
    "KP" TEXT,
    "location" TEXT,
    "microchip" TEXT,
    "HD" TEXT,
    "ED" TEXT,
    "hair" TEXT,
    "color" TEXT,
    CONSTRAINT "Dog_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_countryId_fkey" FOREIGN KEY ("countryId") REFERENCES "Country" ("idCountry") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Dog_cityId_fkey" FOREIGN KEY ("cityId") REFERENCES "City" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Dog_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "DogCategory" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "DogImage" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "dogId" INTEGER NOT NULL,
    "image" TEXT NOT NULL,
    "default" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "DogImage_dogId_fkey" FOREIGN KEY ("dogId") REFERENCES "Dog" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "DogOwner" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "dogId" INTEGER NOT NULL,
    "ownerId" INTEGER NOT NULL,
    "type" TEXT NOT NULL,
    "dateFrom" DATETIME,
    "dateTo" DATETIME,
    "remarks" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "DogOwner_dogId_fkey" FOREIGN KEY ("dogId") REFERENCES "Dog" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Litter" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "ownerId" INTEGER,
    "kennelId" INTEGER,
    "breedId" INTEGER NOT NULL,
    "breedLocation" TEXT,
    "dob" DATETIME NOT NULL,
    "matingDate" DATETIME NOT NULL,
    "registeredDogs" INTEGER,
    "noOfPuppies" INTEGER NOT NULL,
    "sireId" INTEGER NOT NULL,
    "damId" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "cityId" INTEGER,
    "noOfFemale" INTEGER,
    "noOfMale" INTEGER,
    "noOfExpired" INTEGER,
    CONSTRAINT "Litter_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Litter_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Litter_cityId_fkey" FOREIGN KEY ("cityId") REFERENCES "City" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Litter_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "LitterDetail" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "litterId" INTEGER NOT NULL,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "sex" TEXT NOT NULL,
    "color" TEXT,
    "hair" TEXT,
    "dnaTaken" BOOLEAN NOT NULL DEFAULT false,
    "microchip" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "KP" TEXT,
    CONSTRAINT "LitterDetail_litterId_fkey" FOREIGN KEY ("litterId") REFERENCES "Litter" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "StudCertificate" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "sireId" INTEGER NOT NULL,
    "damId" INTEGER NOT NULL,
    "breedId" INTEGER NOT NULL,
    "matingDate" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "status" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "StudCertificate_sireId_fkey" FOREIGN KEY ("sireId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "StudCertificate_damId_fkey" FOREIGN KEY ("damId") REFERENCES "Dog" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "StudCertificate_breedId_fkey" FOREIGN KEY ("breedId") REFERENCES "Breed" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "Notification" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "description" TEXT NOT NULL,
    "refId" INTEGER NOT NULL,
    "refModel" TEXT NOT NULL,
    "reminder" TEXT NOT NULL,
    "dismissTime" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "DogCategory" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Dog_KP_key" ON "Dog"("KP");

-- CreateIndex
CREATE UNIQUE INDEX "LitterDetail_KP_key" ON "LitterDetail"("KP");
